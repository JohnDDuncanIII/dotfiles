 ____________________________________________________________ 
 
  Winamp X v1.0 - By DeeLight (XMMS Version)
 ____________________________________________________________ 

  Please see readme.txt for the main info about the skin.
 ____________________________________________________________ 

  I have altered the original Winamp skin to be linux 
  friendly :) by changing the title bar and adding tux
  instead of the winamp logo.

  21/5/01 - minor update
  Following up on comments on XMMS.com ... I've added
  the clutter bar.  I hadn't even noticed it was missing :)

 ____________________________________________________________ 


