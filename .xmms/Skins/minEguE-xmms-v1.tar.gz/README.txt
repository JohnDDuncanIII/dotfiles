
minEguE XMMS Skin
=================

This XMMS skin is loosely based on the and the Enlightenment minEguE theme
and the XMMS Ultrafina skin . Any feedback welcome :o)

Thanks to:
  - Ben (frantb@rpi.edu) for the Enlightenment minEguE theme.
  - The unknow author of the XMMS Ultrafina skin.

This skin is released under the GNU GPL; see the file COPYING.

Andr�as Saudemont
andreas.saudemont@caramail.com
