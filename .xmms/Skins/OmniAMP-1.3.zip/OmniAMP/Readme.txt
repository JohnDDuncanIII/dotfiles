OmniAMP 1.3 - Released 06.19.2000
   by: gLaNDix (glandix@linuxfreak.com)
   
TABLE OF CONTENTS

   1.   INTRODUCTION
   2.   INSTALLATION
   3.   ABOUT
   4.   CREDITS
   5.   CONTACT
   6.   LEGAL
    	

1. INTRODUCTION

Thank you for downloading this skin!  You can find the latest version of Winamp
at www.winamp.com (atleast v1.9x iirc) and XMMS (used to be X11AMP) at
www.xmms.org (get atleast v1.0.1 since as of this writing, it is the latest
version).


2. INSTALLATION

If you are running recent versions of Winamp or XMMS, it should be enuf to throw
the OmniAMP.zip file into your c:\Program Files\Winamp\Skins dir (for
WinBlows) or your ~/.xmms/Skins dir (for XMMS/X11AMP).


3. ABOUT

This is my second Winamp skin.  I created OmniMP3 for CoolPlayer, and figured 
I'd create one, since there wasn't an OmniCD-ish skin out there already!
Most of the "widgets" were taken from the xpm's found in CDPlayer.app for
linux.  They were converted to gif's using ImageMagik for Win32.
I hope you enjoy this skin as much as I enjoyed creating it!


4. CREDITS

Idea and creation: Jesse Kaufman (gLaNDix)
All art created in GIMP (the GNU Image Manipulation Program) running on
Windows NT Workstation 4.  (yes, GIMP for Win32!!!)


5. CONTACT

E-Mail: glandix@linuxfreak.com
URL   : http://www.linuxfreak.com/~glandix
ICQ   : gLaNDix (4022791)


6. LEGAL

The GIMP is property of Spencer Kimball & Peter Mattis et al.
WinBlows is obviously a Microcrap creation, but who cares? : ^ )
Winamp is Copyright � 1997-1998 Nullsoft, Inc. and Justin Frankel.
Winamp is a trademark of Nullsoft, Inc.
