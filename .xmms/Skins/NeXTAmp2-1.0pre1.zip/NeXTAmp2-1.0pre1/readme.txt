NeXTAmp2 v1.0pre1 - Pre-released September 14, 1999
   

TABLE OF CONTENTS

   1.   INTRODUCTION
   2.   INSTALLATION
   3.   ABOUT
   4.   CREDITS
   5.   CONTACT
   6.   LEGAL
    	

1. INTRODUCTION

Thank you for downloading this skin. Make sure you have at least Winamp 1.91 
or the latest version of XMMS/X11AMP (www.xmms.org) to ensure the support of 
transparency. For full support check www.winamp.com for the latest release of
Winamp.


2. INSTALLATION

If you are running recent versions of Winamp or XMMS, it should be enuf to throw
the NeXTAmp2.zip file into your c:\Program Files\winamp\Skins dir (for windoze) 
or your ~/.xmms/Skins dir (for XMMS/*NIX).


3. ABOUT

This is my first Winamp skin.  I wanted something to look nice with my Window 
Maker desktop in Linux, so I searched for NeXTSTEP(tm) themes, but all fell
short of my picky-ness.  So...  NeXTAmp2 was born!  I took the BeOS theme by
Jan T. Sott (yathosho@altalavista.net) and re-did all the graphics. (I used the
BeOS theme, because the creater did a GREAT job at making the different bitmap
files easy to decipher...  THANKS!!!)  Most of the "widgets" were taken from
screenshots of WINGs running on my linux box, then just shrunk to fit winamp's
small size.  I hope you enjoy it as much as I enjoyed creating it!


4. CREDITS

Idea and creation: Jesse Kaufman (gLaNDix)
Based on BeOS by: Jan T. Sott
All art created in GIMP (the GNU Image Manipulation Program) running on Debian
GNU/Linux 2.1 (slink) on a Pentium 200MHz computer, while running the Window
Maker windowmanager.

5. CONTACT

E-Mail: glandix@linuxfreak.com
URL   : http://www.linuxfreak.com/~glandix


6. LEGAL

NeXT and NeXTSTEP are trademarks of NeXTSTEP, now incorperated into Apple.

Winamp is Copyright � 1997-1998 Nullsoft, Inc. and Justin Frankel.
Winamp is a trademark of Nullsoft, Inc.