SKIN NAME: m2n
SKIN VERSION: 1.0
DATE CREATED: Wed Mar 14 20:04:35 PST 2001
SKIN DESIGNER: Todd Weaver
EMAIL: todd@m2n.com
SKIN GRAPHICS BY: Todd Weaver
EMAIL: todd@m2n.com
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

DESIGNER NOTES:

After using xmms for quite awhile, and trying
many, many themes, I took all the things I liked,
all the tricks I learned, and created this skin.

This skin uses transparency, therefore, it shows
whatever is behind it.

Great pains were taken for accuracy, consistancy,
shaded modes, color matching, and of course coolness.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

CHANGE LOG:
V1.0
- None
