HeliXMMS 1.0 - XMMS/WinAmp theme

This is a theme I made using the Helix Sawfish and GTK themes for design, and
working off the NeXTAmp theme, although most of the graphics from it have
been replaced. This theme is released under the GNU General Public License.

The NeXTAmp theme is from glandix@linuxfreak.com. NeXT is a trademark of
Apple, Inc. Helix Code, the "capsule" Helix Code logo, and the image of the
dancing monkey are all trademarks of Helix Code, Inc.

 - Joe "piman" Wreschnig, piman@pfnet.org
