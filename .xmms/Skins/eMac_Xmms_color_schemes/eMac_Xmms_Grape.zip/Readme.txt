SKIN NAME: eMac XMMS (eMac-schemes)
SKIN VERSION: 1.0
DATE CREATED: 10 November, 1999
SKIN DESIGNERS: JazzMidi & Alf
EMAILS: jazzmidi@mindspring.com
        ried@si.tn.tudelft.nl
SKIN GRAPHICS BY: Archon (Jon Rista)
EMAIL: archon_s@hotmail.com
ARCHON URL:
http://www.geocities.com/researchtriangle/thinktank/2631
ETHEMES URL: http://e.themes.org
XMMS URL : http://www.xmms.org
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SKIN & DESIGNER NOTES:
This skin was designed to go with the eMac
Enlightenment Theme by Archon. Color schemes include:
Blueberry, Bondiblue, Grape, Lime, Strawberry,and Tangerine.
Pick your flavor and have fun.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
ACKNOWLEDGEMENTS:
To Archon - for creating a nice looking OS Etheme.

To - all the people who created and improved
the GIMP :-)

To the Xmms crew - thank you for making a wonderful
mp3 player. Keep up the great work.

To the enlightenment crew - you guys are the best.
Thanks and keep improving e. Looking good!

To You - thank you for downloading our skin.

Enjoy!
JazzMidi
Jazz Alley XG Midis
jazzmidi@mindspring.com
Alf
ried@si.tn.tudelft.nl
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
CHANGE LOG:
V1.0
- First Release
