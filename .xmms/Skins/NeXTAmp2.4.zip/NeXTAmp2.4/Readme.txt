NeXTAmp2.4 - Released 07.17.2000
   by: gLaNDix (glandix@linuxfreak.com)

TABLE OF CONTENTS

   1.   INTRODUCTION
   2.   INSTALLATION
   3.   ABOUT
   4.   CREDITS
   5.   CONTACT
   6.   LEGAL
    	

1. INTRODUCTION

Thank you for downloading this skin!  You can find the latest version of Winamp
at www.winamp.com (atleast v1.9x iirc) and XMMS (used to be X11AMP) at
www.xmms.org (get atleast v1.0.1 since as of this writing, it is the latest
version).


2. INSTALLATION

If you are running recent versions of Winamp or XMMS, it should be enuf to throw
the NeXTAmp2.2.zip file into your c:\Program Files\winamp\Skins dir (for
WinBlows) or your ~/.xmms/Skins dir (for XMMS/X11AMP).


3. ABOUT

This is my first Winamp skin.  I wanted something to look nice with my Window 
Maker desktop in Linux, so I searched for NeXTSTEP(tm) themes, but all fell
short of my picky-ness.  So...  NeXTAmp2 was born!  I took the BeOS theme by
Jan T. Sott (yathosho@altalavista.net) and re-did all the graphics. (I used the
BeOS theme, because the creater did a GREAT job at making the different bitmap
files easy to decipher...  THANKS!!!)  Most of the "widgets" were taken from
screenshots of WINGs running on my linux box, then just shrunk to fit winamp's
small size & then touched them up to make them look slick, like NeXTSTEP.  I
hope you enjoy it as much as I enjoyed creating it!


4. CREDITS

Idea and creation: Jesse Kaufman (gLaNDix)
Based on BeOS by: Jan T. Sott
All art created in GIMP (the GNU Image Manipulation Program) running on Debian
GNU/Linux 2.1 (Slink) on a Pentium 200MHz computer, while running the Window
Maker window manager.


5. CONTACT

E-Mail: glandix@linuxfreak.com
URL   : http://www.linuxfreak.com/~glandix
ICQ   : gLaNDix (4022791)


6. LEGAL

NeXT and NeXTSTEP are trademarks of NeXTSTEP, now incorperated into Apple.
Window Maker is Copyright � 1997-1998 Alfredo K. Kojima.
                Copyright � 1998, 1999 Dan Pascu.
The GIMP is property of Spencer Kimball & Peter Mattis et al.
Debian information is on www.debian.org

WinBlows is obviously a Microcrap creation, but who cares? : ^ )

Winamp is Copyright � 1997-1998 Nullsoft, Inc. and Justin Frankel.
Winamp is a trademark of Nullsoft, Inc.
