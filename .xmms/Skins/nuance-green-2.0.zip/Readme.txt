nuance-green v2.0 - Released 07.17.2000
   by: gLaNDix (glandix@linuxfreak.com)

TABLE OF CONTENTS

   1.   INTRODUCTION
   2.   INSTALLATION
   3.   ABOUT
   4.   CREDITS
   5.   CONTACT
   6.   LEGAL
    	

1. INTRODUCTION

Thank you for downloading this skin!  You can find the latest version of Winamp
at www.winamp.com (atleast v1.9x iirc) and XMMS (used to be X11AMP) at
www.xmms.org (get atleast v1.2.1 since as of this writing, it is the latest
version).


2. INSTALLATION

If you are running recent versions of Winamp or XMMS, it should be enuf to throw
the nuance.zip file into your c:\Program Files\winamp\Skins dir (for
WinBlows) or your ~/.xmms/Skins dir (for XMMS/X11AMP).


3. ABOUT

This is my fourth Winamp skin, and my second non-OS-based skin.  Well, I was just
toying w/ the idea of a new skin when I got an image of the main buttons in my
head...  from there, i just started pulling stuff out my wazoo to come up w/
"nuance" (so named, because I got the word in my head and couldn't get it out...
plus, it sounds better than <place_name_here>Amp!)  Again, this skin was created
by me PIXEL-BY-PIXEL w/o ripping anyone elses skin off, so please do not rip it
off.  Thx!

I hope you enjoy it as much as I enjoyed creating it!


4. CREDITS

Idea and creation: Jesse Kaufman (gLaNDix)
All art created in GIMP (the GNU Image Manipulation Program) running on
Slackware 7 GNU/Linux on a Pentium 200MHz computer and on a Windows NT 4
Workstation at work (using GIMP for Win32).


5. CONTACT

E-Mail: glandix@linuxfreak.com
URL   : http://www.linuxfreak.com/~glandix
ICQ   : gLaNDix (4022791)


6. LEGAL

Copyright � 2000 Jesse Kaufman (gLaNDix)
Please do not rip this skin off, or use any images / ideas without giving
credit where credit is due and asking for my permission first!

The GIMP is property of Spencer Kimball & Peter Mattis et al.
Winamp is Copyright � 1997-1998 Nullsoft, Inc. and Justin Frankel.
Winamp is a trademark of Nullsoft, Inc.