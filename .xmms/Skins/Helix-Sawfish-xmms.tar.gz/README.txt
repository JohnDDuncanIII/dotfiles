
HeliX-Sawfish XMMS Skin
=======================

This XMMS skin is based heavily on the minEguE skin, which in
turn is loosely based on the and the Enlightenment minEguE theme
and the XMMS Ultrafina skin.

It tries to look nice on the HeliX Sawfish theme. If it doesn't
succeed in your opinion, well tough, it's good enough for me :)

Thanks to Andr�as Saudemont <andreas.saudemont@caramail.com>,
author of the minEgueE skin and Tuomas Kuosmanen <tigert@gimp.org>,
author of the HeliX Sawfish theme.

This skin is released under the GNU GPL; see the file COPYING.


Viljo Viitanen <3v@iki.fi>
