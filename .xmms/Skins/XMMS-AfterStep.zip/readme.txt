Here's to  the coolest X window manager out there!
Skin designed for XMMS but works in KMp3,KMPG and Winamp.