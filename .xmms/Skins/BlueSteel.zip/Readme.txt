SKIN NAME: BlueSteel XMMS
SKIN VERSION: 1.0
DATE CREATED: sep 23, 1999
SKIN DESIGNER: Alf
EMAIL: ried@si.tn.tudelft.nl
SKIN GRAPHICS BY: Hunchback (Daniel Erat)
EMAIL: erat@cats.ucsc.edu - danerat@mindspring.com
WEB SITE: http://www2.ucsc.edu/~erat/
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
SKIN NOTES:
Skin should be used with the BlueSteel Enlightenment theme.
by Hunchback. See http://e.themes.org/ and http://www.enlightenment.org.

DESIGNER NOTES:
This skin was inspired by Hunchback's Enlightenment
Theme called "BlueSteel".
I liked this theme a LOT.
I based my skin on the AbsoluteE XMMS skin by JazzMidi
e-mail : jazzmidi@mindspring.com

I have included a patch for xmms-0.9.5. This changes the colors in the visualization
plugins to make it match more with this theme. It also updates the
gnomexmms/xmms-dock-master.xpm file to better match the BlueSteel Enlightenment
theme.

Have fun !
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
ACKNOWLEDGEMENTS:
To Hunchback for creating a great Etheme
To JazzMidi for creating a cool XMMS theme

Alf
ried@si.tn.tudelft.nl
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
CHANGE LOG:
V1.0
- First Release
