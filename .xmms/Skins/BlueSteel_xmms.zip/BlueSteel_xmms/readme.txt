SKIN NAME: BlueSteel XMMS
SKIN VERSION: 1.0
DATE CREATED: SEP 25, 1999
SKIN DESIGNER: JazzMidi
EMAIL: jazzmidi@mindspring.com
SKIN GRAPHICS BY: hunchback a.k.a. Daniel Erat
EMAIL:erat@cats.ucsc.edu - danerat@mindspring.com
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

DISIGNER NOTES:

BlueSteel was designed to match the BlueSteel
Theme for Enlightenment. All credit goes to
the author of BlueSteel.

If you want to learn more about BlueSteel and
other Enlightenment themes - Just visit:
http://www.themes.org

Thank you for downloading this skin.

Enjoy!

JazzMidi
Jazz Alley XG Midis
jazzmidi@mindspring.com

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

CHANGE LOG:
V1.0
- None
